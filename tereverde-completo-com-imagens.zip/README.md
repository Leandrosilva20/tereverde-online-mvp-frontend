# Circuito Terê Verde — MVP Front-End

**Integrante:** Leandro Bragança da Silva

Projeto pronto para ser publicado no GitHub Pages.

## Como publicar

1. Descompacte os arquivos e envie todo o conteúdo para o repositório:
   - index.html
   - trilhas.html
   - biodiversidade.html
   - admin.html
   - css/style.css
   - js/main.js
2. No GitHub: Settings → Pages → Branch: main, Folder: / (root) → Save
3. Aguarde ~1 minuto e acesse: https://SEU_USUARIO.github.io/NOME_DO_REPOSITORIO/

## Login (demo)
- Email: admin@tere.com
- Senha: senha123
